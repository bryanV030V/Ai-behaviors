﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace Steering
{
    [CreateAssetMenu(menuName = "AI_and_PlayerStats/PlayerStats")]
    public class PlayerStats : ScriptableObject
    {
        [Header("SteeringSettings")]
        public float Playermass = 70f;
        public float MaxDesiredVelocity = 3.0f;
        public float MaxSteeringForce = 3.0f;
        public float MaxSpeed = 3f; // SPEED PLAYER IN M/S

    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Steering
{
    public class simpelSeek : MonoBehaviour
    {
        [SerializeField] PlayerStats GetStats;

        [SerializeField] GameObject player;

        [Header("SteeringRuntime")]
        public Vector3 PlayerPos = Vector3.zero; //current playerpos
        public Vector3 TargetPos = Vector3.zero; //Needed playerpos
        public Vector3 PlayerMoveVelocity = Vector3.zero; // current Velocity
        public Vector3 PlayerMoveVelocityNeeded = Vector3.zero; // Needed Velocity
        public Vector3 Steering = Vector3.zero; //Needed Steering angle



        public void Start()
        {
            PlayerPos = transform.position;
            TargetPos = PlayerPos;


        }



        private void Update()
        {

            TargetPos = player.transform.position;
            TargetPos.y = player.transform.position.y;

        }


        private void FixedUpdate()
        {
            PlayerMoveVelocityNeeded = (TargetPos - PlayerPos).normalized * GetStats.MaxDesiredVelocity;
            Vector3 SteeringForce = PlayerMoveVelocityNeeded - PlayerMoveVelocity;

            Steering = Vector3.zero;
            Steering += SteeringForce;

            Steering = Vector3.ClampMagnitude(Steering, GetStats.MaxSteeringForce);
            Steering /= GetStats.Playermass;

            PlayerMoveVelocity = Vector3.ClampMagnitude(PlayerMoveVelocity + Steering, GetStats.MaxSpeed);
            PlayerPos += PlayerMoveVelocity * Time.fixedDeltaTime;

            transform.position = PlayerPos;
            transform.LookAt(PlayerPos + Time.fixedDeltaTime * PlayerMoveVelocity);



        }







        public void OnDrawGizmos()
        {
            DrawRay(transform.position, PlayerMoveVelocity, Color.blue);
            DrawRay(transform.position, PlayerMoveVelocityNeeded, Color.yellow);


            DrawLabel(transform.position, name, Color.red);


            UnityEditor.Handles.color = Color.cyan;
            UnityEditor.Handles.DrawSolidDisc(TargetPos, Vector3.up, 0.25f);

        }


        static void DrawRay(Vector3 position, Vector3 Direction, Color color)
        {
            if (Direction.sqrMagnitude > 0.001f)
            {
                Debug.DrawRay(position, Direction, color);
                UnityEditor.Handles.color = color;
                UnityEditor.Handles.DrawSolidDisc(position + Direction, Vector3.up, 0.25f);
            }




        }
        static void DrawLabel(Vector3 position, string lable, Color color)
        {
            UnityEditor.Handles.BeginGUI();
            UnityEditor.Handles.color = color;
            UnityEditor.Handles.Label(position, lable);
            UnityEditor.Handles.EndGUI();




        }
    }




}



﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



namespace Steering
{
    public class WayPoint : MonoBehaviour
    {
        [SerializeField] protected float DrawDistanse = 1f;




        public void OnDrawGizmos()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(transform.position, DrawDistanse);
        }


    }
}
